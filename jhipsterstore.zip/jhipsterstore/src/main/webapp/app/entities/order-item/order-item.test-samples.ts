import { OrderItemStatus } from 'app/entities/enumerations/order-item-status.model';

import { IOrderItem, NewOrderItem } from './order-item.model';

export const sampleWithRequiredData: IOrderItem = {
  id: 2322,
  quantity: 31654,
  totalPrice: 15728,
  status: 'OUT_OF_STOCK',
};

export const sampleWithPartialData: IOrderItem = {
  id: 15841,
  quantity: 29836,
  totalPrice: 6591,
  status: 'BACK_ORDER',
};

export const sampleWithFullData: IOrderItem = {
  id: 3075,
  quantity: 12193,
  totalPrice: 16908,
  status: 'AVAILABLE',
};

export const sampleWithNewData: NewOrderItem = {
  quantity: 25755,
  totalPrice: 31265,
  status: 'OUT_OF_STOCK',
  id: null,
};

Object.freeze(sampleWithNewData);
Object.freeze(sampleWithRequiredData);
Object.freeze(sampleWithPartialData);
Object.freeze(sampleWithFullData);
