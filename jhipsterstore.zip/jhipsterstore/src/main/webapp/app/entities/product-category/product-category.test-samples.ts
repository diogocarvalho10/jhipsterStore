import { IProductCategory, NewProductCategory } from './product-category.model';

export const sampleWithRequiredData: IProductCategory = {
  id: 23098,
  name: 'Bonaire, overbalance kooky',
};

export const sampleWithPartialData: IProductCategory = {
  id: 6715,
  name: 'adored approach',
  description: 'Southeast architectures Shoes',
};

export const sampleWithFullData: IProductCategory = {
  id: 31167,
  name: 'Southeast invoice woman',
  description: 'Volvo azure salmon',
};

export const sampleWithNewData: NewProductCategory = {
  name: 'Steel',
  id: null,
};

Object.freeze(sampleWithNewData);
Object.freeze(sampleWithRequiredData);
Object.freeze(sampleWithPartialData);
Object.freeze(sampleWithFullData);
