import dayjs from 'dayjs/esm';

import { OrderStatus } from 'app/entities/enumerations/order-status.model';

import { IProductOrder, NewProductOrder } from './product-order.model';

export const sampleWithRequiredData: IProductOrder = {
  id: 29552,
  placedDate: dayjs('2023-09-20T02:16'),
  status: 'PENDING',
  code: 'Mazda',
};

export const sampleWithPartialData: IProductOrder = {
  id: 9907,
  placedDate: dayjs('2023-09-20T01:25'),
  status: 'PENDING',
  code: 'white under',
};

export const sampleWithFullData: IProductOrder = {
  id: 23690,
  placedDate: dayjs('2023-09-19T17:18'),
  status: 'COMPLETED',
  code: 'Sedan',
};

export const sampleWithNewData: NewProductOrder = {
  placedDate: dayjs('2023-09-20T02:54'),
  status: 'PENDING',
  code: 'Elegant',
  id: null,
};

Object.freeze(sampleWithNewData);
Object.freeze(sampleWithRequiredData);
Object.freeze(sampleWithPartialData);
Object.freeze(sampleWithFullData);
