import dayjs from 'dayjs/esm';

import { IShipment, NewShipment } from './shipment.model';

export const sampleWithRequiredData: IShipment = {
  id: 17730,
  date: dayjs('2023-09-19T22:07'),
};

export const sampleWithPartialData: IShipment = {
  id: 8472,
  trackingCode: 'sapiente Organic',
  date: dayjs('2023-09-20T04:45'),
};

export const sampleWithFullData: IShipment = {
  id: 31573,
  trackingCode: 'Tasty Pine brushing',
  date: dayjs('2023-09-20T04:05'),
  details: 'Accountability',
};

export const sampleWithNewData: NewShipment = {
  date: dayjs('2023-09-19T19:07'),
  id: null,
};

Object.freeze(sampleWithNewData);
Object.freeze(sampleWithRequiredData);
Object.freeze(sampleWithPartialData);
Object.freeze(sampleWithFullData);
