import dayjs from 'dayjs/esm';

import { InvoiceStatus } from 'app/entities/enumerations/invoice-status.model';
import { PaymentMethod } from 'app/entities/enumerations/payment-method.model';

import { IInvoice, NewInvoice } from './invoice.model';

export const sampleWithRequiredData: IInvoice = {
  id: 30314,
  date: dayjs('2023-09-19T18:41'),
  status: 'CANCELLED',
  paymentMethod: 'CASH_ON_DELIVERY',
  paymentDate: dayjs('2023-09-20T01:45'),
  paymentAmount: 23563,
};

export const sampleWithPartialData: IInvoice = {
  id: 26384,
  date: dayjs('2023-09-20T04:20'),
  status: 'ISSUED',
  paymentMethod: 'CASH_ON_DELIVERY',
  paymentDate: dayjs('2023-09-19T14:34'),
  paymentAmount: 3287,
  code: 'Frozen',
};

export const sampleWithFullData: IInvoice = {
  id: 7007,
  date: dayjs('2023-09-20T08:12'),
  details: 'North',
  status: 'ISSUED',
  paymentMethod: 'PAYPAL',
  paymentDate: dayjs('2023-09-19T12:09'),
  paymentAmount: 8887,
  code: 'West systemic',
};

export const sampleWithNewData: NewInvoice = {
  date: dayjs('2023-09-19T15:22'),
  status: 'CANCELLED',
  paymentMethod: 'PAYPAL',
  paymentDate: dayjs('2023-09-20T01:05'),
  paymentAmount: 12995,
  id: null,
};

Object.freeze(sampleWithNewData);
Object.freeze(sampleWithRequiredData);
Object.freeze(sampleWithPartialData);
Object.freeze(sampleWithFullData);
