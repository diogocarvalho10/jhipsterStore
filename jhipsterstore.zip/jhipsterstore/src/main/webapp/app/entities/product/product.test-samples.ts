import { IProduct, NewProduct } from './product.model';

export const sampleWithRequiredData: IProduct = {
  id: 19903,
  name: 'administration',
  price: 7453,
};

export const sampleWithPartialData: IProduct = {
  id: 29365,
  name: 'Brand logistical',
  price: 22319,
};

export const sampleWithFullData: IProduct = {
  id: 23470,
  name: 'Pop',
  description: 'frigid',
  price: 12986,
  image: '../fake-data/blob/hipster.png',
  imageContentType: 'unknown',
};

export const sampleWithNewData: NewProduct = {
  name: 'supposing invoice',
  price: 24215,
  id: null,
};

Object.freeze(sampleWithNewData);
Object.freeze(sampleWithRequiredData);
Object.freeze(sampleWithPartialData);
Object.freeze(sampleWithFullData);
