import { Gender } from 'app/entities/enumerations/gender.model';

import { ICustomer, NewCustomer } from './customer.model';

export const sampleWithRequiredData: ICustomer = {
  id: 5374,
  firstName: 'Enos',
  lastName: 'Tremblay',
  gender: 'FEMALE',
  email: ')wnl@LO.eFza',
  phone: '(417) 715-5590 x5989',
  addressLine1: 'Coordinator Nevada Central',
  city: 'Blandacester',
  country: 'China',
};

export const sampleWithPartialData: ICustomer = {
  id: 10789,
  firstName: 'Kimberly',
  lastName: 'Durgan',
  gender: 'MALE',
  email: "32@xfp:L.p-'r",
  phone: '397.585.8026 x0734',
  addressLine1: 'Innovative',
  city: 'Port Allisonstead',
  country: 'Saint Helena',
};

export const sampleWithFullData: ICustomer = {
  id: 6364,
  firstName: 'David',
  lastName: 'Doyle',
  gender: 'MALE',
  email: 'l@r}.LPRSw',
  phone: '578.928.0360',
  addressLine1: 'Cambridgeshire Convertible tie',
  addressLine2: 'Focused',
  city: 'Greenfelderstad',
  country: 'Netherlands',
};

export const sampleWithNewData: NewCustomer = {
  firstName: 'Nickolas',
  lastName: 'Hackett',
  gender: 'MALE',
  email: '5@iN.:R:',
  phone: '508.610.0857 x788',
  addressLine1: 'Rustic Titanium',
  city: 'Arecibo',
  country: 'Reunion',
  id: null,
};

Object.freeze(sampleWithNewData);
Object.freeze(sampleWithRequiredData);
Object.freeze(sampleWithPartialData);
Object.freeze(sampleWithFullData);
