export enum OrderItemStatus {
  AVAILABLE = 'AVAILABLE',

  OUT_OF_STOCK = 'OUT_OF_STOCK',

  BACK_ORDER = 'BACK_ORDER',
}
