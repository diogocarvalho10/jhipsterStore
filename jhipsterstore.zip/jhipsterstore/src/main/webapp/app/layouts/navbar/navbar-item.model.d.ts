type NavbarItem = {
  name: string;
  route: string;
  translationKey: string;
};

export default NavbarItem;
