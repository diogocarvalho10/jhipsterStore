/**
 * Application root.
 */
package com.jhipsterstore.app;
