/**
 * Service layer.
 */
package com.jhipsterstore.app.service;
