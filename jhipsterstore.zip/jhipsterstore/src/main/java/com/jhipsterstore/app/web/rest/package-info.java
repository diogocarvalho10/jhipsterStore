/**
 * Rest layer.
 */
package com.jhipsterstore.app.web.rest;
