package com.jhipsterstore.app.service.mapper;

import com.jhipsterstore.app.domain.Invoice;
import com.jhipsterstore.app.domain.ProductOrder;
import com.jhipsterstore.app.service.dto.InvoiceDTO;
import com.jhipsterstore.app.service.dto.ProductOrderDTO;
import org.mapstruct.*;

/**
 * Mapper for the entity {@link Invoice} and its DTO {@link InvoiceDTO}.
 */
@Mapper(componentModel = "spring")
public interface InvoiceMapper extends EntityMapper<InvoiceDTO, Invoice> {
    @Mapping(target = "order", source = "order", qualifiedByName = "productOrderCode")
    InvoiceDTO toDto(Invoice s);

    @Named("productOrderCode")
    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "id", source = "id")
    @Mapping(target = "code", source = "code")
    ProductOrderDTO toDtoProductOrderCode(ProductOrder productOrder);
}
