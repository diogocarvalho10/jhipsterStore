/**
 * Logging aspect.
 */
package com.jhipsterstore.app.aop.logging;
