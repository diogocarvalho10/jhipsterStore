package com.jhipsterstore.app.domain.enumeration;

/**
 * The InvoiceStatus enumeration.
 */
public enum InvoiceStatus {
    PAID,
    ISSUED,
    CANCELLED,
}
