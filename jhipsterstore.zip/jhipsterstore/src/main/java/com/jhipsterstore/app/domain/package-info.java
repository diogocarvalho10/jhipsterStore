/**
 * Domain objects.
 */
package com.jhipsterstore.app.domain;
