package com.jhipsterstore.app.service.mapper;

import com.jhipsterstore.app.domain.OrderItem;
import com.jhipsterstore.app.domain.Product;
import com.jhipsterstore.app.domain.ProductOrder;
import com.jhipsterstore.app.service.dto.OrderItemDTO;
import com.jhipsterstore.app.service.dto.ProductDTO;
import com.jhipsterstore.app.service.dto.ProductOrderDTO;
import org.mapstruct.*;

/**
 * Mapper for the entity {@link OrderItem} and its DTO {@link OrderItemDTO}.
 */
@Mapper(componentModel = "spring")
public interface OrderItemMapper extends EntityMapper<OrderItemDTO, OrderItem> {
    @Mapping(target = "product", source = "product", qualifiedByName = "productName")
    @Mapping(target = "order", source = "order", qualifiedByName = "productOrderCode")
    OrderItemDTO toDto(OrderItem s);

    @Named("productName")
    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "id", source = "id")
    @Mapping(target = "name", source = "name")
    ProductDTO toDtoProductName(Product product);

    @Named("productOrderCode")
    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "id", source = "id")
    @Mapping(target = "code", source = "code")
    ProductOrderDTO toDtoProductOrderCode(ProductOrder productOrder);
}
