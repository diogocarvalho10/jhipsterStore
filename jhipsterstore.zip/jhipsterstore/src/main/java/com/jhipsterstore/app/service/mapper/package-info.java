/**
 * Data transfer objects mappers.
 */
package com.jhipsterstore.app.service.mapper;
