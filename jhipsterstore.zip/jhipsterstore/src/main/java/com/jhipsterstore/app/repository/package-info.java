/**
 * Repository layer.
 */
package com.jhipsterstore.app.repository;
