package com.jhipsterstore.app.domain.enumeration;

/**
 * The Gender enumeration.
 */
public enum Gender {
    MALE,
    FEMALE,
    OTHER,
}
