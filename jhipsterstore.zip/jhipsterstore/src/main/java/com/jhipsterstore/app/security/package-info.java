/**
 * Application security utilities.
 */
package com.jhipsterstore.app.security;
