/**
 * Rest layer error handling.
 */
package com.jhipsterstore.app.web.rest.errors;
