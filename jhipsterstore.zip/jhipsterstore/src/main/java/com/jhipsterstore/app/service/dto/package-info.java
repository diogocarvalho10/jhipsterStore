/**
 * Data transfer objects for rest mapping.
 */
package com.jhipsterstore.app.service.dto;
