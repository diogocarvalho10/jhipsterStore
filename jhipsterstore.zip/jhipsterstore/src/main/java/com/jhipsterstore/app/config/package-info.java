/**
 * Application configuration.
 */
package com.jhipsterstore.app.config;
