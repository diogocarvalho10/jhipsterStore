package com.jhipsterstore.app.service.mapper;

import com.jhipsterstore.app.domain.Customer;
import com.jhipsterstore.app.domain.ProductOrder;
import com.jhipsterstore.app.service.dto.CustomerDTO;
import com.jhipsterstore.app.service.dto.ProductOrderDTO;
import org.mapstruct.*;

/**
 * Mapper for the entity {@link ProductOrder} and its DTO {@link ProductOrderDTO}.
 */
@Mapper(componentModel = "spring")
public interface ProductOrderMapper extends EntityMapper<ProductOrderDTO, ProductOrder> {
    @Mapping(target = "customer", source = "customer", qualifiedByName = "customerEmail")
    ProductOrderDTO toDto(ProductOrder s);

    @Named("customerEmail")
    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "id", source = "id")
    @Mapping(target = "email", source = "email")
    CustomerDTO toDtoCustomerEmail(Customer customer);
}
